import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, ArrowUpRight } from "lucide-react";
import { projects } from "@/data/projects";

export function generateStaticParams() {
  return projects.map((project) => ({ slug: project.slug }));
}

export default async function ProjectPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const project = projects.find((p) => p.slug === slug);
  if (!project) notFound();

  return (
    <main className="min-h-screen pt-28">
      <section className="px-5 md:px-10 pb-20">
        <Link href="/#work" className="inline-flex items-center gap-2 text-sm text-white/45 hover:text-white transition-colors">
          <ArrowLeft size={15}/> Back to work
        </Link>
        <div className="mt-16 grid md:grid-cols-[1fr_280px] gap-10">
          <div>
            <p className="text-sm uppercase tracking-[.25em] text-white/45">{project.number} / {project.year}</p>
            <h1 className="display-sm mt-7">{project.title}<span className="text-[#ff5a36]">.</span></h1>
            <p className="mt-8 max-w-2xl text-xl md:text-2xl text-white/55 leading-relaxed">{project.description}</p>
          </div>
          <div className="md:pt-12">
            <p className="text-sm text-white/45 mb-4">DISCIPLINE</p>
            <p>{project.category}</p>
            <div className="mt-8 flex flex-wrap gap-2">
              {project.tags.map((tag) => <span key={tag} className="border border-white/15 rounded-full px-3 py-1 text-xs">{tag}</span>)}
            </div>
          </div>
        </div>
      </section>

      <section className={`mx-5 md:mx-10 h-[55vh] md:h-[75vh] rounded-2xl ${project.gradient} relative overflow-hidden`}>
        <div className="absolute inset-0 grid-lines" />
        <div className="absolute left-6 bottom-6 text-xs uppercase tracking-widest text-white/60">Replace this preview with your final project image</div>
      </section>

      <section className="px-5 md:px-10 py-24 grid md:grid-cols-2 gap-12">
        <div>
          <p className="text-sm text-white/45 uppercase tracking-[.2em]">Project story</p>
          <h2 className="text-4xl md:text-6xl font-bold tracking-[-.05em] mt-5">Concept → Design → Final</h2>
        </div>
        <div className="text-white/55 leading-relaxed space-y-6">
          <p>Add your case-study explanation here: the brief, creative idea, visual direction, tools used and final outcome.</p>
          <p>This template is intentionally structured so you can turn each project into a professional Behance-style case study.</p>
        </div>
      </section>

      <section className="px-5 md:px-10 pb-24">
        <div className="border-t border-white/15 pt-6 flex justify-between">
          <Link href="/#contact" className="text-2xl font-bold">Start a project</Link>
          <ArrowUpRight />
        </div>
      </section>
    </main>
  );
}