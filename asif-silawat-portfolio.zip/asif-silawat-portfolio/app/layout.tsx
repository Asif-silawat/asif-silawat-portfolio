import type { Metadata } from "next";
import "./globals.css";
import { Navbar } from "@/components/Navbar";
import { CustomCursor } from "@/components/CustomCursor";

export const metadata: Metadata = {
  title: "Asif Silawat — Graphic Designer & 3D Artist",
  description: "Portfolio of Asif Silawat — Graphic Designer, 3D Artist and Visual Creative.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>
        <CustomCursor />
        <Navbar />
        {children}
      </body>
    </html>
  );
}