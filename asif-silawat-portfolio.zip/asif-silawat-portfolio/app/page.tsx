"use client";

import { motion } from "framer-motion";
import { ArrowDown, ArrowUpRight, Mail } from "lucide-react";
import { projects } from "@/data/projects";
import { ProjectCard } from "@/components/ProjectCard";
import { Reveal } from "@/components/Reveal";

export default function Home() {
  return (
    <main id="top" className="overflow-hidden">
      <section className="min-h-screen relative grid-lines noise flex flex-col justify-end px-5 md:px-10 pb-8 pt-32">
        <div className="absolute top-1/2 right-[8%] w-32 h-32 md:w-56 md:h-56 rounded-full border border-white/15 animate-[spin_20s_linear_infinite]" />
        <div className="absolute top-[48%] right-[12%] w-16 h-16 rounded-full bg-[#ff5a36] blur-[1px]" />
        <div className="relative">
          <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: .2 }} className="text-sm uppercase tracking-[.3em] text-white/45 mb-8">
            Graphic Designer · 3D Artist · Visual Creative
          </motion.p>
          <motion.h1
            initial={{ y: 90, opacity: 0 }} animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 1, ease: [.22,1,.36,1] }}
            className="display max-w-[1200px]"
          >
            ASIF<br />SILAWAT<span className="text-[#ff5a36]">.</span>
          </motion.h1>
          <div className="mt-10 flex flex-col md:flex-row md:items-end justify-between gap-8">
            <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: .8 }} className="max-w-md text-white/55 leading-relaxed">
              I create visual experiences through graphic design, branding, 3D visualization, social media and motion.
            </motion.p>
            <a href="#work" className="w-28 h-28 rounded-full border border-white/25 flex items-center justify-center gap-1 hover:bg-white hover:text-black transition-colors">
              Explore <ArrowDown size={15} />
            </a>
          </div>
        </div>
      </section>

      <section id="work" className="px-5 md:px-10 py-28 md:py-40">
        <Reveal>
          <div className="flex items-end justify-between mb-16">
            <div>
              <p className="text-sm text-white/45 mb-5">SELECTED WORK / 2026</p>
              <h2 className="display-sm">Selected<br />work.</h2>
            </div>
            <span className="hidden md:block text-white/35 text-sm">06 projects</span>
          </div>
        </Reveal>
        <div>
          {projects.map((project, i) => (
            <Reveal key={project.slug} delay={i * .04}>
              <ProjectCard project={project} />
            </Reveal>
          ))}
        </div>
      </section>

      <section id="about" className="px-5 md:px-10 py-28 md:py-40 bg-[#f3f1eb] text-black">
        <Reveal>
          <p className="text-sm uppercase tracking-[.25em] text-black/45 mb-10">About me</p>
          <div className="grid md:grid-cols-[1fr_1.2fr] gap-10">
            <h2 className="display-sm">Design<br />with intent.</h2>
            <div className="max-w-2xl">
              <p className="text-2xl md:text-4xl leading-[1.1] tracking-[-.04em]">
                I&apos;m Asif Silawat, a graphic designer and 3D artist focused on turning ideas into clear, memorable visual stories.
              </p>
              <p className="mt-8 text-black/55 leading-relaxed max-w-xl">
                My work combines art direction, branding, social media design, packaging, 3D visualization and motion. I enjoy moving between concept and execution while keeping the final visual simple, strong and purposeful.
              </p>
            </div>
          </div>
        </Reveal>
      </section>

      <section id="services" className="px-5 md:px-10 py-28 md:py-40">
        <Reveal>
          <p className="text-sm uppercase tracking-[.25em] text-white/45 mb-12">Services</p>
          <div className="grid md:grid-cols-2">
            {["Brand Identity", "Social Media", "3D Design", "Packaging", "Motion Graphics", "AI Creative"].map((item, i) => (
              <div key={item} className="border-t border-white/15 py-7 flex justify-between items-center group">
                <span className="text-3xl md:text-5xl font-bold tracking-[-.05em]">{item}</span>
                <span className="text-white/30 group-hover:text-[#ff5a36] transition-colors">0{i + 1}</span>
              </div>
            ))}
          </div>
        </Reveal>
      </section>

      <section id="contact" className="px-5 md:px-10 pt-20 pb-10 bg-[#ff5a36] text-black">
        <Reveal>
          <p className="text-sm uppercase tracking-[.25em] mb-10">Have a project?</p>
          <h2 className="display-sm max-w-5xl">LET&apos;S MAKE<br />SOMETHING<br />GREAT<span className="text-white">.</span></h2>
          <div className="mt-16 flex flex-col md:flex-row justify-between gap-8 border-t border-black/20 pt-7">
            <a href="mailto:hello@asifsilawat.com" className="text-xl md:text-2xl flex items-center gap-3 hover:opacity-60">
              <Mail size={20} /> hello@asifsilawat.com
            </a>
            <div className="flex gap-6 text-sm">
              <a href="#" className="flex items-center gap-1">Behance <ArrowUpRight size={14}/></a>
              <a href="#" className="flex items-center gap-1">Instagram <ArrowUpRight size={14}/></a>
              <a href="#" className="flex items-center gap-1">LinkedIn <ArrowUpRight size={14}/></a>
            </div>
          </div>
        </Reveal>
        <footer className="mt-24 border-t border-black/20 pt-5 flex justify-between text-xs uppercase tracking-widest">
          <span>© 2026 Asif Silawat</span>
          <span>Built for visual thinkers</span>
        </footer>
      </section>
    </main>
  );
}