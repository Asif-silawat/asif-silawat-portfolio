"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import type { Project } from "@/data/projects";

export function ProjectCard({ project }: { project: Project }) {
  return (
    <Link href={`/work/${project.slug}`} className="group block border-t border-white/15 py-6 md:py-8">
      <div className="grid md:grid-cols-[90px_1fr_260px_40px] gap-5 items-center">
        <span className="text-sm text-white/45">{project.number}</span>
        <div>
          <h3 className="text-4xl md:text-6xl font-bold tracking-[-.055em] group-hover:translate-x-2 transition-transform duration-500">
            {project.title}
          </h3>
          <p className="mt-2 text-sm text-white/45">{project.category}</p>
        </div>
        <motion.div
          className={`hidden md:block h-36 rounded-xl overflow-hidden ${project.gradient}`}
          whileHover={{ scale: 1.04, rotate: -1 }}
          transition={{ duration: .35 }}
        >
          <div className="h-full w-full flex items-end p-4">
            <span className="text-xs uppercase tracking-widest text-white/70">Preview</span>
          </div>
        </motion.div>
        <ArrowUpRight className="text-white/45 group-hover:text-white group-hover:translate-x-1 group-hover:-translate-y-1 transition-all" />
      </div>
    </Link>
  );
}