"use client";

import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowUpRight, Menu, X } from "lucide-react";

const links = [
  ["Work", "#work"],
  ["About", "#about"],
  ["Services", "#services"],
  ["Contact", "#contact"],
];

export function Navbar() {
  const [open, setOpen] = useState(false);

  return (
    <>
      <header className="fixed top-0 left-0 right-0 z-50 px-5 md:px-10 py-5 mix-blend-difference text-white">
        <div className="flex items-center justify-between">
          <a href="#top" className="font-bold tracking-[-.04em] text-lg">ASIF SILAWAT®</a>
          <nav className="hidden md:flex items-center gap-8 text-sm">
            {links.map(([label, href]) => (
              <a key={label} href={href} className="hover:opacity-60 transition-opacity">{label}</a>
            ))}
            <a href="#contact" className="border border-white/40 rounded-full px-4 py-2 flex items-center gap-2 hover:bg-white hover:text-black transition-colors">
              Let&apos;s talk <ArrowUpRight size={15} />
            </a>
          </nav>
          <button aria-label="Open menu" className="md:hidden" onClick={() => setOpen(true)}>
            <Menu />
          </button>
        </div>
      </header>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ x: "100%" }} animate={{ x: 0 }} exit={{ x: "100%" }}
            transition={{ duration: .45, ease: [.76,0,.24,1] }}
            className="fixed inset-0 z-[60] bg-[#f3f1eb] text-black p-6"
          >
            <div className="flex justify-between">
              <span className="font-bold">ASIF SILAWAT®</span>
              <button aria-label="Close menu" onClick={() => setOpen(false)}><X /></button>
            </div>
            <nav className="mt-24 flex flex-col">
              {links.map(([label, href], i) => (
                <motion.a
                  key={label} href={href} onClick={() => setOpen(false)}
                  initial={{ y: 40, opacity: 0 }} animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: i * .07 }}
                  className="border-b border-black/15 py-5 text-5xl font-bold tracking-[-.06em]"
                >
                  {label}
                </motion.a>
              ))}
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}